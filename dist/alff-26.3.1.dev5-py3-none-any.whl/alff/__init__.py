"""ALFF: Automated Frameworks for Active-Learning Graph-Based Machine Learning Force Fields and Materials Property Calculations.

<img src="https://thangckt.github.io/alff_doc/1images/kde_color_128x128.png" style="float: left; margin-right: 20px" width="120"/>

Developed and maintained by [C.Thang Nguyen](https://thangckt.github.io)
"""

from pathlib import Path

ALFF_ROOT = Path(__file__).parent

try:
    from ._version import version as __version__
except ImportError:
    __version__ = "0.1_fallback"

__author__ = "C.Thang Nguyen"
__contact__ = "http://thangckt.github.io/email"


# warnings.filterwarnings(action="ignore", module=".*paramiko.*")
